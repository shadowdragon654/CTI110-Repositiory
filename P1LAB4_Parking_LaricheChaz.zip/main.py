print('  NO PARKING\n2:00 - 6:00 a.m.')


